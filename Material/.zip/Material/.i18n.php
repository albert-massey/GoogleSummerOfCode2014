<?php
# Internationalisation for MyForm extension
# @FILLME!

$messages=array();
$messages['en']=array(
'mtdesc'=>'Used for material information manage',
'Name'=>'material',
);
$messages['qqq'] = array(
	'myf-desc' => '{{desc}}'
);
 
# French
$messages['fr'] = array(
        'myf-desc' => 'Une extension générique utilisée par le tutoriel d\'HTMLForm'
);
