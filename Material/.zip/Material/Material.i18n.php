<?php
# Internationalisation for Material-extension
# @FILLME!

$messages=array();
$messages['en']=array(
'mtdesc'=>'Used for storing material properties',
'Name'=>'material',
);
$messages['qqq'] = array(
	'myf-desc' => '{{desc}}'
);
 
# French
$messages['fr'] = array(
        'myf-desc' => 'Une extension générique utilisée par le tutoriel d\'HTMLForm'
);
