<?php
	/**
	 * Aliases for Special:Material
	 *
	 * @file
	 * @ingroup Extensions
	 */

	$specialPageAliases=array();
		$specialPageAliases['en']=array(
		'material'=>array('Material'),
		);























