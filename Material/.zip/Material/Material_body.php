<?php
# Here the necessary description of file, authors and license
# @FILLME!
# Always good to remind that important part
 
# Avoids illegal processing, doesn't cost much, but unnecessary on a correct installation
if (!defined('MEDIAWIKI')) { die(-1); } 
class SpecialMaterial extends SpecialPage{
public function __construct($request=null){
parent::__construct('Material');
}
public function execute($par){
global $wgUser;
global $wgOut;
$wgOut->setPageTitle(wfMessage('Name'));

if($wgUser->isLoggedIn()){

$this->setHeaders();
$formDescriptor=array(
'field1'=>array(
'section'=>'section',
'class'=>'HTMLTextField',
'label'=>'Material Id'
),
'field2'=>array(
'section'=>'section',
'class'=>'HTMLTextField',
'label'=>'Material Name'
),
'field3'=>array(
'section'=>'section',
'class'=>'HTMLTextField',
'label'=>'Boiling Point'
),
'field4'=>array(
'section'=>'section',
'class'=>'HTMLTextField',
'label'=>'Density'
),
'field5'=>array(
'section'=>'section',
'class'=>'HTMLTextField',
'label'=>'Melting Point'
),
'field6'=>array(
'section'=>'section',
'class'=>'HTMLTextField',
'label'=>'Tensile Strength'
),
);
$htmlForm=new HTMLForm($formDescriptor,$this->getContext(),'material');
$htmlForm->setSubmitText('Submit');
$htmlForm->setSubmitCallback(array('SpecialMaterial','processInt'));
$htmlForm->show();
}
}
static function processInt($formData){
if($formData['field1']){
$db=wfGetDB(DB_MASTER);

$d=array(
'matdb_id'=>$formData['field1'],
'matdb_name'=>$formData['field2'],
'matdb_bp'=>$formData['field3'],
'matdb_d'=>$formData['field4'],
'matdb_mp'=>$formData['field5'],
'matdb_ts'=>$formData['field6'],
);
$db->insert('material',$d,__METHOD__);
$db->commit(__METHOD__);
return "Ok Data is Inserted";
}
else{
return 'Try Again';
}
}

}

